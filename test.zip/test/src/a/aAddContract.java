package a;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

public class aAddContract extends HttpServlet {
    public User user=new User();
    private static final long serialVersionUID =1L;
    public aAddContract() {
        super();
    }
    public void destroy() {
        super.destroy(); // Just puts "destroy" string in log
        // Put your code here
    }
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        this.doPost(request, response);

    }
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
        out.println("<HTML>");
        out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
        out.println("  <BODY>");
        try {
            Mysql mysql=new Mysql();
            mysql.SetSelectSQL("select * from house where houseid=\""+request.getParameter("houseid")+"\"");
            Contract contract=new Contract();
            contract.setSdate(request.getParameter("select1")+request.getParameter("select2"));
            contract.setEdate(request.getParameter("select3")+request.getParameter("select4"));
            contract.setAuserid(Integer.parseInt(request.getParameter("userid")));
            contract.setHouid(Integer.parseInt(request.getParameter("houseid")));
            while (mysql.resultSet.next())
            {
                contract.setBuserid(Integer.parseInt(mysql.resultSet.getString("userid")));
                contract.setPay(Integer.parseInt(mysql.resultSet.getString("pay"))*(Integer.parseInt(request.getParameter("select4"))-Integer.parseInt(request.getParameter("select2"))+12*(Integer.parseInt(request.getParameter("select3"))-Integer.parseInt(request.getParameter("select1")))));
            }
            out.println("合同签订成功");
            out.println("正在跳转至合同信息页面······");
            mysql.SetChangeSQL("insert into contract values(0,\""+contract.getSdate()+"\","+contract.getEdate()+",\""+contract.getHouid()+"\",0,"+contract.getAuserid()+","+contract.getBuserid()+","+contract.getPay()+",0)");
        }catch (Exception e)
        {
            System.out.println(e);
        }
        response.setHeader("refresh", "1;URL=aContractInformation.jsp?userid="+request.getParameter("userid"));
        out.println("  </BODY>");
        out.println("</HTML>");
        out.flush();
        out.close();
    }


    public void init() throws ServletException {
        // Put your code here
    }
}
