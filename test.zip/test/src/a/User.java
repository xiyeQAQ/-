package a;
public class User {

    private int id;
    private String password;
    private int userid;
    private String name;
    private int number;
    private int indentity;


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getIndentity() {
        return indentity;
    }

    public void setIndentity(int indentity) {
        this.indentity = indentity;
    }
}