package a;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Mysql {
    public ResultSet resultSet;
    public Statement statement;
    public Connection connection;
    public void SetSelectSQL(String SQL)throws ClassNotFoundException, SQLException
    {
        String driver = "com.mysql.jdbc.Driver";
        String URL = "jdbc:mysql://localhost:3306/RentManagementSystem?useUnicode=true&characterEncoding=utf-8&serverTimezone=GMT%2B8&useSSL=false";
        String USER = "root";
        String PASSWORD = "3647749";
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        Statement st = conn.createStatement();
        //ResultSet rs = st.executeQuery(SQL);
        ResultSet rs = st.executeQuery(SQL);
        resultSet=rs;
        statement=st;
        connection=conn;
    }
    public void SetChangeSQL(String SQL)throws ClassNotFoundException, SQLException
    {
        String driver = "com.mysql.jdbc.Driver";
        String URL = "jdbc:mysql://localhost:3306/RentManagementSystem?useUnicode=true&characterEncoding=utf-8&serverTimezone=GMT%2B8&useSSL=false";
        String USER = "root";
        String PASSWORD = "3647749";
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        Statement st = conn.createStatement();
        st.execute(SQL);
        st.close();
        conn.close();
    }
    public static void main(String args[])
    {
        //test
    }
}
