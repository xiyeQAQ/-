package a;

public class Contract {
    private int conid;
    private String sdate;
    private String edate;
    private int houid;
    private int notid;
    private int auserid;
    private int buserid;
    private int pay;

    public int getConid() {
        return conid;
    }

    public void setConid(int conid) {
        this.conid = conid;
    }

    public String getSdate() {
        return sdate;
    }

    public void setSdate(String sdate) {
        this.sdate = sdate;
    }

    public String getEdate() {
        return edate;
    }

    public void setEdate(String edate) {
        this.edate = edate;
    }

    public int getHouid() {
        return houid;
    }

    public void setHouid(int houid) {
        this.houid = houid;
    }

    public int getPay() {
        return pay;
    }

    public void setPay(int pay) {
        this.pay = pay;
    }

    public int getAuserid() {
        return auserid;
    }

    public void setAuserid(int auserid) {
        this.auserid = auserid;
    }

    public int getBuserid() {
        return buserid;
    }

    public void setBuserid(int buserid) {
        this.buserid = buserid;
    }

    public int getNotid() {
        return notid;
    }

    public void setNotid(int notid) {
        this.notid = notid;
    }
}
