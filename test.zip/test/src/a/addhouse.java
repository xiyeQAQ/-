package a;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

public class addhouse extends HttpServlet {
    private static final long serialVersionUID =1L;

    public addhouse() {
        super();
    }

    public void destroy() {
        super.destroy(); // Just puts "destroy" string in log
        // Put your code here
    }
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        this.doPost(request, response);

    }
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
        out.println("<HTML>");
        out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
        out.println("  <BODY>");
        House house=new House();
        try{
            HttpSession session =request.getSession();
            house.setArea(request.getParameter("area"));
            house.setRoom(request.getParameter("room"));
            house.setRenovate(request.getParameter("renovate"));
            house.setUserid(Integer.parseInt(request.getParameter("userid")));
            house.setPay(Integer.parseInt(request.getParameter("pay")));
            Mysql mysql=new Mysql();
            mysql.SetChangeSQL("insert into house values(0,\""+house.getArea()+"\",\""+house.getRoom()+"\",\""+house.getRenovate()+"\","+house.getUserid()+","+house.getPay()+")");
            response.sendRedirect("bhouseinformation.jsp?userid="+house.getUserid());
        }
        catch(Exception e){
            System.out.println(e);
        }
        out.println("  </BODY>");
        out.println("</HTML>");
        out.flush();
        out.close();
    }


    public void init() throws ServletException {
        // Put your code here
    }
}
