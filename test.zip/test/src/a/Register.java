package a;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;


public class Register extends HttpServlet {


    private static final long serialVersionUID =1L;

    public Register() {
        super();
    }

    public void destroy() {
        super.destroy(); // Just puts "destroy" string in log
        // Put your code here
    }

    /**
     * The doGet method of the servlet. <br>

     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        this.doPost(request, response);

    }

    /**
     * The doPost method of the servlet. <br>

     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
        out.println("<HTML>");
        out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
        out.println("  <BODY>");
        try{
            User user=new User();
            user.setId(Integer.parseInt(request.getParameter("username")));
            user.setPassword(request.getParameter("password"));
            user.setName(request.getParameter("name"));
            user.setNumber(Integer.parseInt(request.getParameter("number")));
            user.setIndentity(Integer.parseInt(request.getParameter("identity")));
            Mysql mysql=new Mysql();
            mysql.SetChangeSQL("insert into users values(0,\""+user.getName()+"\","+user.getId()+",\""+user.getPassword()+"\","+user.getNumber()+","+user.getIndentity()+")");
        }
        catch(Exception e){
            System.out.println(e);
        }
        out.println("<a>注册成功</a>");
        response.setHeader("refresh", "1;URL=login.jsp");
        out.println("  </BODY>");
        out.println("</HTML>");
        out.flush();
        out.close();
    }


    public void init() throws ServletException {
        // Put your code here
    }
}
