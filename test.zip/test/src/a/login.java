package a;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;


public class login extends HttpServlet {
    public User user=new User();

    private static final long serialVersionUID =1L;

    public login() {
        super();
    }

    public void destroy() {
        super.destroy(); // Just puts "destroy" string in log
        // Put your code here
    }
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        this.doPost(request, response);

    }
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
        out.println("<HTML>");
        out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
        out.println("  <BODY>");
        try{
            user.setId(Integer.parseInt(request.getParameter("username")));
            user.setPassword(request.getParameter("password"));
            Mysql mysql=new Mysql();
            mysql.SetSelectSQL("select * from users where id=\""+user.getId()+"\"");
            if(mysql.resultSet.next()){
                if (user.getPassword().equals(mysql.resultSet.getString("password")))
                {
                    user.setId(Integer.parseInt(mysql.resultSet.getString("id")));
                    user.setUserid(Integer.parseInt(mysql.resultSet.getString("userid")));
                    user.setPassword(mysql.resultSet.getString("password"));
                    user.setName(mysql.resultSet.getString("name"));
                    user.setNumber(Integer.parseInt(mysql.resultSet.getString("number")));
                    user.setIndentity(Integer.parseInt(mysql.resultSet.getString("identity")));
                    String a="0";
                    if (a.equals(mysql.resultSet.getString("identity"))) {
                        out.println("<a>欢迎租户</a>");
                        response.sendRedirect("ahouseinformation.jsp?userid="+user.getUserid());
                     } else {
                        out.println("<a>欢迎承租人</a>");
                        response.sendRedirect("brentinformation.jsp?userid="+user.getUserid());
                    }
                }
                else
                {
                    out.println("<a>密码错误</a>");
                    response.setHeader("refresh", "1;URL=login.jsp");
                }
            }
            else
            {
                out.println("<a>用户名不存在</a>");
                response.setHeader("refresh", "1;URL=login.jsp");
            }
            mysql.resultSet.close();
            mysql.statement.close();
            mysql.connection.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        out.println("  </BODY>");
        out.println("</HTML>");
        out.flush();
        out.close();
    }


    public void init() throws ServletException {
        // Put your code here
    }
}
